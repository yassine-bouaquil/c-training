#include <stdio.h>

int main()
{
  printf("Hello Xnano M	! \n");

  return 0;
}
