# C Boilerplate

Ready to go c envirement.

## Installation:
- Download the c boilerplate:
```
wget https://github.com/Youcode-Classe-E-2023-2024/boilerplate/archive/main.tar.gz
```
- Unzip:
```
tar -xf main.tar.gz
```
- Start using `cd boilerplate-main`

## CMD:
- `make run`: run the program.
- `make clean`: clean temp and cache.
- `make push M="<message>"`: fetch, pull, add all, commit and push.
